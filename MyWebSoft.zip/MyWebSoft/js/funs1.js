let comments = [];
let com_obj = {}
function myFunction(){
    let commentName = document.getElementById("comment-name");
    console.log('ZZZZZZZZZZZZZZZZZZ', commentName);
    let commentBody = document.getElementById("comment-body");
   
    let com = {
        "name": [commentName.value, commentBody.value, Math.floor(Date.now()/1000)],
        
    }
    com_obj = com;
    console.log(com.name[0],"com com com");
    
    
    let comment_place1 = document.getElementById("comment_place1").innerHTML=       com.name[0];
     let comment_place2 = document.getElementById("comment_place2").innerHTML=com/name[1];
    let comment_place3 = document.getElementById("comment_place3").innerHTML=Math.floor(Date.now()/1000) ;
    console.log(comment_place1);
    console.log(comment_place2);
    console.log(comment_place3);
   console.log(comments,"fsadfasdfasf");
}


    console.log(com_obj.name,"com_obj");





    

