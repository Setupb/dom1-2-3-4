let comments = [];

function myFunction(){
    let commentName = document.getElementById("comment-name");
    console.log('ZZZZZZZZZZZZZZZZZZ', commentName);
    let commentBody = document.getElementById("comment-body");
    
    let comment = {
        name : commentName.value,
        body : commentBody.value,
        time : Math.floor(Date.now()/1000)  
    }
    
    commentName.value = "";
    commentBody.value = "";
    
    comments.push(comment);
    
   
    saveComments();
    showComments();
}

myFunction();
function saveComments(){
    localStorage.setItem("comments", JSON.stringify(comments));
}

function showComments(){
    let commentField = document.getElementById("comment-field");
    let out = "";
    comments.forEach(function(item){
        out += `<p class="text-right small">$(timeConverter(item.time))</p>`;
        out += `<p class="alert alert-primary"> $(item.name) </p>`;  
        out += `<p class="alert alert-success"> $(item.body) </p>`;
})
}
    

function timeConverter(UNIX_timastramp){
    var a = new Date(UNIX_timastramp * 1000);
    var months = ["01", "02", "03", "04", "05","06","07","08","09", "10", "11", "12"];
    var year = a.getFullYear(a.getMonth());
    var date = a.getDate();
    var hour = a.getHours();
    var min = a.getMinutes();
    var sec = a.getSeconds();
    var time = date+ " "+months+" "+ year +" "+hour+" "+ min+" "+sec;
    return time;
}

document.getElementById("myslide").onmousemove = function(event){
    var x = event.offsetX;
    console.log(x);
    document.getElementById("two").style.width = x+"px";
}
document.getElementById("myslide").onmouseleave = function(event){
    document.getElementById("two").style.width = "1000px"; 
}
