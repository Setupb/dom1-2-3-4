function one() {
    document.getElementById("one").innerHTML = "I was pressed!!";
}
function three() {
    document.getElementById("two").innerHTML = "Mouse on me!";
}
function two(){
    document.getElementById("two").innerHTML = "Mouse is not on me!";
}
