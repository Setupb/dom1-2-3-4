const a = document.getElementById("list");
a.setAttribute("class", "list");
const a1 = document.querySelectorAll(".list");
const newUl = document.createElement("ul");
newUl.setAttribute("id", "list1");
newUl.setAttribute("class", "list1");
const newUl1 = document.querySelectorAll(".list1");

const a11=a1[0].querySelectorAll("li")

console.log(a11);



const firstEl = document.querySelector('.list');
const  secEl = a11[4];
const tEl = a11[1];
const fEl = a11[3];
const fiveEl = a11[2];

console.log(secEl,"sec");

const user1 = firstEl.firstElementChild;
const user2 = secEl;
const user3 = tEl;
const user4 = fEl;
const user5 = fiveEl;


newUl.appendChild(user1);
newUl.appendChild(user2);
newUl.appendChild(user3);
newUl.appendChild(user4);
newUl.appendChild(user5);


console.log(newUl,"newUl");


